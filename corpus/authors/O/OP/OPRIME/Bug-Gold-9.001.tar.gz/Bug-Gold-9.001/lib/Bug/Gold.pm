package Bug::Gold;
our $VERSION = '9.001';
1

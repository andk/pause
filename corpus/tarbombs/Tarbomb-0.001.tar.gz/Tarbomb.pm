package Tarbomb;
our $VERSION = 1.000;
1;

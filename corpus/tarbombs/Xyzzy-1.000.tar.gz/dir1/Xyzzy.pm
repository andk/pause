package Xyzzy;
our $VERSION = 1.234;

1;

package Xyzzy::Plugh;
our $VERSION = 1;
1;

package Bug::Gold;
our $VERSION = '10.001';
1

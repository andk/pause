package perl::rocks;
our $VERSION = 6.00;
1

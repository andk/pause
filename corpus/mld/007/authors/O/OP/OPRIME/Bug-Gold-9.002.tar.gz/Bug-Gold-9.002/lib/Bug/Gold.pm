package Bug::Gold;
our $VERSION = '9.002';
1

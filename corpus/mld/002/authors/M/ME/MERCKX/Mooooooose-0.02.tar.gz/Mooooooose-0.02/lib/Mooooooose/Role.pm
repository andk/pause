package Mooooooose::Role;
our $VERSION = '0.02';
1

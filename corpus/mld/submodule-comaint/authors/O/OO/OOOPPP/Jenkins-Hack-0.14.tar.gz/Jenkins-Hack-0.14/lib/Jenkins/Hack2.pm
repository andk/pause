package Jenkins::Hack2;
our $VERSION = '0.14';
1

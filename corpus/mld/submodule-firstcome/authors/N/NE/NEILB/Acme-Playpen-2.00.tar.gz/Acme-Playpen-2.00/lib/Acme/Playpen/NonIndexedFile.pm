package Acme::Playpen::NonIndexedFile;

1;

package Acme::Playpen::NonIndexedPackage;

1;

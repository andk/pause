package Acme::Playpen::Utilities;

use strict;
use warnings;

# Nothing to see here, move along.

# That means you too, Toby :-)

1;

=head1 NAME

Acme::Playpen::Utilities - I'm just this module, you know

=head1 SYNOPSIS

 # do nothing

=head1 DESCRIPTION

Danger Will Robinson! This is a developer version -- don't install it unless you're sure!

Acme::Playpen::Utilities is a nothing little module,
used while i'm checking various things related to the CPAN toolchain.


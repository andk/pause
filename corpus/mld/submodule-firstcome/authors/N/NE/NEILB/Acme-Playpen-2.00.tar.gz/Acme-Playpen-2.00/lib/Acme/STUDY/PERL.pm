package Acme::STUDY::PERL;

our $VERSION = '2.00';

1;


package Jenkins::Hack2;
our $VERSION = '0.15';
1

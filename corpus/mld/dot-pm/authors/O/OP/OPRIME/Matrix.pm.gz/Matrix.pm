package Matrix;
our $VERSION = '1.000';

sub lead { ... }

1;

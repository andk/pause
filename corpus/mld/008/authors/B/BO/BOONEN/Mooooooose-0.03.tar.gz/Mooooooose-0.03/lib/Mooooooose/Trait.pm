package Mooooooose::Trait;
our $VERSION = '0.03';
1

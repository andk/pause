package Mooooooose::Role;
our $VERSION = '0.03';
1

package VVVVVV;
our $VERSION = '6.666june6';

1;

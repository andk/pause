package VVVVVV;
our $VERSION = '6.666';

1;

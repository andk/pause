package VVVVVV;
our $VERSION = '6.6.6';

1;

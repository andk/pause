package VVVVVV;
our $VERSION = v6.6.6;

1;

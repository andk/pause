package VVVVVV;
our $VERSION = '6.66_6';

1;

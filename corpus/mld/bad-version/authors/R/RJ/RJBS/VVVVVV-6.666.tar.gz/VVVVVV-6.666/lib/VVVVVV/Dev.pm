package VVVVVV::Dev;
our $VERSION = '6.66_6';

1;

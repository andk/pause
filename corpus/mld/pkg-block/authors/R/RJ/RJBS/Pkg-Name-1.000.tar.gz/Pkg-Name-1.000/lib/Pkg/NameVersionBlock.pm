use 5.014;
use strict;
package Pkg::NameVersionBlock 1.000 {

}

1;
